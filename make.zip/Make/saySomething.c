#include <stdio.h>

#include "say.h"

int say(char* word) {
  printf(", %s!\n\n", word);
  return 0;
}
