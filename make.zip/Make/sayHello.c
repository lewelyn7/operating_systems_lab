#include <stdio.h>

#include "say.h"

void sayHello() {
  printf("Hello");
}
